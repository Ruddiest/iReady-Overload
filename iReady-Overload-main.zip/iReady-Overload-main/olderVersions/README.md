# Older Versions
This folder contains older versions of hacks.

# v1
[v1](v1/) only contains the lesson skipper, not the minutes hack. Also, the old lesson skipper was slower and did not work with some lessons.
